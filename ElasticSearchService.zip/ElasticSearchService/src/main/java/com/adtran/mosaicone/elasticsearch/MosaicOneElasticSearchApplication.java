package com.adtran.mosaicone.elasticsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MosaicOneElasticSearchApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(MosaicOneElasticSearchApplication.class, args);
	}

}
