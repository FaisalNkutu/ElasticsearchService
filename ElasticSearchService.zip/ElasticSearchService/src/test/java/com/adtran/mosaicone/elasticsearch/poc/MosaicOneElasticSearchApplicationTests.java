package com.adtran.mosaicone.elasticsearch.poc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MosaicOneElasticSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
